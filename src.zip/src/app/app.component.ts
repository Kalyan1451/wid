import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  conversationFormData!:FormGroup;
  autoResize:boolean=false;
  constructor(private formBuilder:FormBuilder){
   this.prepareForm();
  }
  ngOnInit(): void {

  }
  prepareForm(){
    this.conversationFormData = this.formBuilder.group({
    firstName : ['',Validators.required],
    email:['', Validators.required],
    subject:['',Validators.required],
    message:['', Validators.required],
  })
}
sendMessage()
{
  console.log(this.conversationFormData?.value);
  this.conversationFormData.reset();
}


}




